<?php
// Cek apakah permintaan POST memiliki data
if (isset($_POST['image_path'])) {
    $image_path = $_POST['image_path'];

    // Koneksi ke database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "drawing"; 

    // Buat koneksi
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Cek koneksi
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Siapkan query untuk menyimpan informasi gambar ke dalam database
    $stmt = $conn->prepare("INSERT INTO images (image_path) VALUES (?)");
    $stmt->bind_param("s", $image_path);
    
    if ($stmt->execute()) {
        echo "Image information saved to database.";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Tutup koneksi
    $stmt->close();
    $conn->close();
}



$servername = "localhost";
$username = "root";
$password = "";
$dbname = "drawing";

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Mengambil data gambar berdasarkan timestamp
$sql = "SELECT * FROM images ORDER BY timestamp DESC";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/datatables@1.10.21/media/js/jquery.dataTables.min.js"></script>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Dashboard</a>
    </nav>

    <!-- Content Wrapper -->
    <div class="container-fluid mt-4">
        <!-- Button untuk Generate Gambar -->
        <div class="row">
            <div class="col-lg-12 mb-4">
                <a href="#" class="btn btn-primary">Generate Image</a>
            </div>
        </div>

        <!-- Tabel untuk Menampilkan ID, Timestamp, dan Gambar -->
        <div class="row">
            <div class="col-lg-12 mb-4">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Tabel ID, Timestamp, dan Gambar</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Timestamp</th>
                                        <th>Gambar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Jika ada data gambar, tampilkan dalam tabel
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            echo "<tr>";
                                            echo "<td>" . $row['id'] . "</td>";
                                            echo "<td>" . $row['timestamp'] . "</td>";
                                            echo "<td><img src='" . $row['image_path'] . "' width='100' /></td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='3'>No images found.</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Footer -->
    <footer class="footer bg-dark text-white text-center py-4">
        <p>&copy; 2024 Dashboard. All rights reserved.</p>
    </footer>

    <!-- Optional Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script>
        // Inisialisasi DataTable untuk tabel yang telah dibuat
        $(document).ready(function () {
            $('#dataTable').DataTable();
        });
    </script>

</body>
</html>

<?php
$conn->close();
?>
