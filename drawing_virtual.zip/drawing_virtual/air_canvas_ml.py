# Untuk melihat hasilnya dalam tabel
# pertama letakkan folder ke dalam diretori C:\xampp\htdocs
# kemudian aktifkan apache dan mysql di XAMPP
# lalu masukkan http://localhost/drawing_virtual/fetch_data.php ke browser pencarian

import cv2
import numpy as np
import mediapipe as mp
from collections import deque
import requests

# Arrays to handle color points
bpoints = [deque(maxlen=1024)]
gpoints = [deque(maxlen=1024)]
rpoints = [deque(maxlen=1024)]
ypoints = [deque(maxlen=1024)]

# Indexes for each color
blue_index = 0
green_index = 0
red_index = 0
yellow_index = 0

# Kernel for dilation
kernel = np.ones((5, 5), np.uint8)

# Colors: Blue, Green, Red, Yellow
colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (0, 255, 255)]
colorIndex = 0

# Canvas setup
paintWindow = np.zeros((471, 636, 3)) + 255
buttons = [
    {"rect": (40, 1, 140, 65), "color": (0, 0, 0), "label": "CLEAR"},
    {"rect": (160, 1, 255, 65), "color": (255, 0, 0), "label": "BLUE"},
    {"rect": (275, 1, 370, 65), "color": (0, 255, 0), "label": "GREEN"},
    {"rect": (390, 1, 485, 65), "color": (0, 0, 255), "label": "RED"},
    {"rect": (505, 1, 600, 65), "color": (0, 255, 255), "label": "YELLOW"},
    {"rect": (615, 1, 700, 65), "color": (0, 0, 0), "label": "SAVE"},
]

for button in buttons:
    x1, y1, x2, y2 = button["rect"]
    paintWindow = cv2.rectangle(paintWindow, (x1, y1), (x2, y2), button["color"], 2)
    cv2.putText(
        paintWindow,
        button["label"],
        (x1 + 15, y1 + 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 0, 0) if button["color"] != (0, 0, 0) else (255, 255, 255),
        2,
        cv2.LINE_AA,
    )

cv2.namedWindow("Paint", cv2.WINDOW_AUTOSIZE)

# Mediapipe setup
mpHands = mp.solutions.hands
hands = mpHands.Hands(max_num_hands=1, min_detection_confidence=0.7)
mpDraw = mp.solutions.drawing_utils

# Webcam initialization
cap = cv2.VideoCapture(0)

# Function to save image
def save_image():
    # Simpan gambar ke folder 'images'
    image_path = "images/painted_image.png"
    cv2.imwrite(image_path, paintWindow)
    print(f"Image saved as {image_path}")
    return image_path

# Fungsi untuk mengirim data gambar ke server PHP
def send_image_to_server(image_path):
    url = 'http://localhost/drawing_virtual/fetch_data.php'
    data = {'image_path': image_path}
    try:
        response = requests.post(url, data=data)
        if response.status_code == 200:
            print("Image information saved to database.")
        else:
            print(f"Failed to save image information: {response.status_code}")
    except Exception as e:
        print(f"Error: {e}")

while True:
    # Read frame from webcam
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    framergb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Draw buttons on the frame
    for button in buttons:
        x1, y1, x2, y2 = button["rect"]
        frame = cv2.rectangle(frame, (x1, y1), (x2, y2), button["color"], 2)
        cv2.putText(
            frame,
            button["label"],
            (x1 + 15, y1 + 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (0, 0, 0) if button["color"] != (0, 0, 0) else (255, 255, 255),
            2,
            cv2.LINE_AA,
        )

    # Process hand landmarks
    result = hands.process(framergb)
    if result.multi_hand_landmarks:
        for handslms in result.multi_hand_landmarks:
            landmarks = [(int(lm.x * 640), int(lm.y * 480)) for lm in handslms.landmark]

            mpDraw.draw_landmarks(frame, handslms, mpHands.HAND_CONNECTIONS)

            fore_finger = landmarks[8]
            thumb = landmarks[4]
            cv2.circle(frame, fore_finger, 3, (0, 255, 0), -1)

            if abs(fore_finger[1] - thumb[1]) < 30:
                bpoints.append(deque(maxlen=512))
                gpoints.append(deque(maxlen=512))
                rpoints.append(deque(maxlen=512))
                ypoints.append(deque(maxlen=512))
            elif fore_finger[1] <= 65:
                for i, button in enumerate(buttons):
                    x1, y1, x2, y2 = button["rect"]
                    if x1 <= fore_finger[0] <= x2:
                        if button["label"] == "CLEAR":
                            bpoints, gpoints, rpoints, ypoints = (
                                [deque(maxlen=512)] for _ in range(4)
                            )
                            paintWindow[67:, :, :] = 255
                        elif button["label"] == "SAVE":
                            # Simpan gambar dan kirim informasi ke server
                            image_path = save_image()
                            send_image_to_server(image_path)
                        else:
                            colorIndex = i - 1  
                        break
            else:
                points = [bpoints, gpoints, rpoints, ypoints]
                points[colorIndex][blue_index].appendleft(fore_finger)

    # Draw lines on the canvas and frame
    points = [bpoints, gpoints, rpoints, ypoints]
    for i in range(len(points)):
        for j in range(len(points[i])):
            for k in range(1, len(points[i][j])):
                if points[i][j][k - 1] is None or points[i][j][k] is None:
                    continue
                cv2.line(frame, points[i][j][k - 1], points[i][j][k], colors[i], 2)
                cv2.line(paintWindow, points[i][j][k - 1], points[i][j][k], colors[i], 2)

    cv2.imshow("Output", frame)
    cv2.imshow("Paint", paintWindow)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
